<div class="copyrights">
	 <p>© 2021-22 TMS. Done by Deethya J Reddy(1RN19IS055) & Dravyashree M(1RN19IS059) | <a href="#">TMS</a> </p>
</div>	
